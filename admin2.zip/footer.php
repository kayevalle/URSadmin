

  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      
    </div>
    <strong>Copyright &copy; 2014-2016 <a href="#">University of Rizal System</a>.</strong> All rights
    reserved.
  </footer>