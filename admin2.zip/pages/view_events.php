
<?php include '../head.php' ?>

  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Events
    </h1>
    <ol class="breadcrumb">
      <li><a href="/admin/pages/dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li>Events</li>
      <li class="active">View Events</li>
    </ol>
  </section>

      <!-- Main content -->
      <section class="content">
        

      </section>
      <!-- /.content -->

<!-- ./wrapper -->
<?php include '../script.php' ?>


